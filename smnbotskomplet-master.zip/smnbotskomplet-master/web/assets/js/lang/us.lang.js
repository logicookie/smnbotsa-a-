var lang = {
    "PASSWORD_CHANGED": "Passwort geändert",
    "PASSWORD_CHANGED_MESSAGE": "Dein Passwort wurde geändert",
    "PASSWORD_CHANGED_EMESSAGE": "Die angegebenen Passwörter stimmen nicht überein",

    "ADDRESS_CHANGED": "Adresse geändert",
    "ADDRESS_CHANGED_MESSAGE": "Deine Adresse wurde geändert",

    "DELETE_USER": "Benutzer Löschen",
    "DELETE_USER_SURE": "Du löscht damit dich und all deine Bot's. Bist du dir wirklich sicher?",

    'BOT_CREATED': 'Musicbot Erstellt',
    'BOT_CREATED_MESSAGE': 'Dein Bots wurde erstellt und Du kannst ihn nun benutzen',


    "ERROR": "Verarbeitungsfehler",
    "ERROR_MESSAGE": "Leider gab es einen Fehler beim ausführen der Anfrage"
};